# University Module Submissions

Welcome to the repository for the Cloud Computing DevOps assessment submission. This repository contains all the assessment submissions for this module, organized as ZIP files.

## Instructions

To view the submission content, please follow these steps:

1. **Click on the ZIP file:** Navigate to the "Files" section and click on the ZIP file you want to view.
2. **Download the ZIP file**
3. **Extract the ZIP file:** Once downloaded, extract the contents of the ZIP file to view the submission materials.

Thank you for visiting!
